﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Compsci335Assignment2.Dtos
{
    public class OrderDto
    {
    public int ProductId { get; set; }
    public int Quantity { get; set; }
    }
}
